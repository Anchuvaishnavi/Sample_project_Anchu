module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define(
        'user',
        {
            full_name: {
                type: DataTypes.STRING,
                validate: {
                    notEmpty: {
                        args: true,
                        msg: "full_name cannot be empty"
                    }
                }
            },
            email: {
                type: DataTypes.STRING,
                validate: {
                    isEmail: {
                        args: true,
                        msg: 'The email you entered is invalid'
                    }
                }
            },
            phone: {
                type: DataTypes.STRING,
                validate: {
                    notEmpty: {
                        args: true,
                        msg: "pnone number cannot be empty"
                    }

                },
                unique: {
                    args: true,
                    msg: 'Oops. phone number already exist',

                }
            },
            password: {
                type: DataTypes.STRING,
                validate: {
                    notEmpty: {
                        args: true,
                        msg: "password cannot be empty"
                    }

                },
            },
            address: {
                type: DataTypes.STRING,
                validate: {
                    notEmpty: {
                        args: true,
                        msg: "address cannot be empty"
                    }

                },

            },
        
        },
        {
            defaultScope: {
                attributes: { exclude: ['password'] },
            },
            scopes: {
                // include hash with this scope
                withHash: { attributes: {}, }
            }
        },
    );
    User.associate = function (models) {
        // associations can be defined here
    };
    return User;
};
