module.exports = {
    DB: {
      database: 'enhancing_jwt_user',
      username: 'postgres',
      password: '12345',
      host: 'localhost',
      dialect: 'postgres',
      port: 5432,
      define: {
        freezeTableName: true,
      }
      }
}