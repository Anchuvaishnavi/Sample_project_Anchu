const bcrypt = require('bcryptjs');
const { user } = require('../../models');
const errorHandle = require('../../../utils/errorHandle');
const { generateToken } = require('../../../utils/jwt');

module.exports = async (req, res) => {
    try {
        await user.sync({ force: false });
        let { email, password } = req.body;

        let user_data = await user.scope('withHash').findOne({ where: { email } });

        if (!user_data || !(await bcrypt.compare(password, user_data.password))) {
            res.status(400).json({ message: "Invalid credentials!" });
            return;
        }
        
        let { id, full_name, phone, address } = user_data;

        const jwtToken = generateToken({ id, full_name, email, phone, address});
        res.send({ access_token: jwtToken, full_name:user_data.full_name, email: user_data.email, phone: user_data.phone });


    } catch (err) {
        console.log(err)
        const { status, message, error } = errorHandle(err);
        res.status(status).json({ status, message, error })
    }
}