const Sequelize = require('sequelize');
let CONFIG = require('./index');

const sequelize = new Sequelize(
    CONFIG.DB.database,
    CONFIG.DB.username,
    CONFIG.DB.password,
    {
        host: CONFIG.DB.host,
        dialect: CONFIG.DB.dialect,
      
    },
);

sequelize
    .authenticate()
    .then(() => {
        console.log('Connection has been established successfully.');
    })
    .catch((err) => {
        console.error('Unable to connect to the database:', err);
    });
