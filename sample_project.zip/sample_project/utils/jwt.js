const jwt = require('jsonwebtoken');
const JWT_SECRET_TOKEN = 'SEC_ENHANC_USER';

const { user } = require('../API/models')

/**
 * Generate jwt token for user data
 * data: user data
 * cb: callback function
 */
generateToken = (data, cb) => {
    return jwt.sign({ user: data }, JWT_SECRET_TOKEN);
};

/**
 * Verify data
 * token: jwt token
 * cb: callback function
 */
verifyToken = (token, cb) => {
    console.log(token)
    return jwt.verify(token, JWT_SECRET_TOKEN);
};
validateToken = async (req, res, next) => {
    let token = req.headers['authorization'];
    if (token && typeof token !== 'undefined') {
        verifyToken(token, function (err, authData) {
            console.log(authData)
            if (err) {
                res.status(403).json({ code: 403, message: "Token invalid" })
            } else {

            }
        });
        let validate = verifyToken(token);
        req.token = token;
        req.authData = validate;
        next();
    } else {
        res.status(403).json({ code: 401, message: "Token invalid" });
    }

};


module.exports = {
    generateToken,
    verifyToken,
    validateToken
}