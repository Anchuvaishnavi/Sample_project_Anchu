const routes = require('express').Router();
const jwt = require('../../utils/jwt');


const register = require('../controller/auth/register');
const login = require('../controller/auth/login');

routes.post('/register', register);
routes.post('/login', login);


module.exports = routes;