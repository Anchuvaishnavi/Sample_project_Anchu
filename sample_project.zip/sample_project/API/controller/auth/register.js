const bcrypt = require('bcryptjs');
const { user } = require('../../models')
const errorHandle = require('../../../utils/errorHandle');

module.exports = async (req, res) => {
    try {
       await user.sync({ force: false });

        let {
            full_name,
            email,
            phone,
            password,
            address
        } = req.body;
        let check_email = await user.findOne({
            where: {
                email: email
            }
        })
        if (check_email) {
            res.status(409).send({
                success: false,
                message: "This Email Address Already Exists"
            });
            return;
        }
        let check_mobile = await user.findOne({
            where: {
                phone: phone
            }
        })
        if (check_mobile) {
            res.status(409).send({
                success: false,
                message: "This Mobile Number  Already Exists"
            });
            return;
        }
        let create_user = await user.create
            ({
                full_name: full_name,
                email: email,
                phone: phone,
                password: await bcrypt.hash(password, 10),
                address: address
            })

        res.status(201).send({
            success: true,
            message: "User Registered Successfully!",
            result: create_user
        });
    }

    catch (err) {
        console.log(err);
        const { status, message, error } = errorHandle(err);
        res.status(status).json({ status, message, error })
    }
}